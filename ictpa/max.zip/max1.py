# max1.py
max = 0

a = int(raw_input("Enter the first number: "))
b = int(raw_input("Enter the second number: "))
c = int(raw_input("Enter the third number: "))
d = int(raw_input("Enter the fourth number: "))
e = int(raw_input("Enter the fifth number: "))

if a > max:
    max = a
if b > max:
    max = b
if c > max:
    max = c
if d > max:
    max = d
if e > max:
    max = e

print "The maximum is", max
