# max2.py
# This program should output the maximum number

# Initialising the maximum number
max = 0


# Maximum between 1st input and max
x = int(raw_input("Enter the first number: "))
if x > max:
    max = x

# Maximum between all inputs so far and max
x = int(raw_input("Enter the second number: "))
if x > max:
    max = x

# Maximum between all inputs so far and max
x = int(raw_input("Enter the third number: "))
if x > max:
    max = x

# Maximum between all inputs so far and max
x = int(raw_input("Enter the fourth number: "))
if x > max:
    max = x

# Maximum between all inputs so far and max
x = int(raw_input("Enter the fifth number: "))
if x > max:
    max = x

# Print the maximum
print "The maximum number is", max
