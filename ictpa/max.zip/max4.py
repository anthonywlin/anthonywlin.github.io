# max4.py
# This program should output the maximum number


# Initialising the maximum number
max = 0

### Defining the function mymax(a,b) which returns the maximum of a and b
def mymax(a,b):
    if a > b:
        return a
    else:
        return b


# Maximum between 1st input and max
x = int(raw_input("Enter the first number: "))
max = mymax(max,x)

# Maximum between all inputs so far and max
x = int(raw_input("Enter the second number: "))
max = mymax(max,x)

# Maximum between all inputs so far and max
x = int(raw_input("Enter the third number: "))
max = mymax(max,x)

# Maximum between all inputs so far and max
x = int(raw_input("Enter the fourth number: "))
max = mymax(max,x)

# Maximum between all inputs so far and max
x = int(raw_input("Enter the fifth number: "))
max = mymax(max,x)

# Print the maximum
print "The maximum number is", max
