# max0.py

a = int(raw_input("Enter the first number: "))
b = int(raw_input("Enter the second number: "))
c = int(raw_input("Enter the third number: "))
d = int(raw_input("Enter the fourth number: "))
e = int(raw_input("Enter the fifth number: "))

if a >= b:
    if a >= c:
        if a >= d:
            if a>= e:
                print "The maximum is", a
            else:
                print "The maximum is", e
        elif d>=e:
            print "The maximum is", d
        else:
            print "The maximum is", e
    elif c >= d:
        if c >= e:
            print "The maximum is", c
        else:
            print "The maximum is", e
    elif d >= e:
        print "The maximum is", d
    else:
        print "The maximum is", e
else:       
    if b >= c:
        if b >= d:
            if b>= e:
                print "The maximum is", b
            else:
                print "The maximum is", e
        elif d>=e:
            print "The maximum is", d
        else:
            print "The maximum is", e
    elif c >= d:
        if c >= e:
            print "The maximum is", c
        else:
            print "The maximum is", e
    elif d >= e:
        print "The maximum is", d
    else:
        print "The maximum is", e
