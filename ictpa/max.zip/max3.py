# max3.py
# This program should output the maximum number


# Initialising the maximum number
max = 0

### Defining the function mymax(a)
### which sets to the global variable max the maximum of the input a
### and max
def mymax(a):
    global max
    if a > max:
        max = a


# Maximum between 1st input and max
x = int(raw_input("Enter the first number: "))
mymax(x)

# Maximum between all inputs so far and max
x = int(raw_input("Enter the second number: "))
mymax(x)

# Maximum between all inputs so far and max
x = int(raw_input("Enter the third number: "))
mymax(x)

# Maximum between all inputs so far and max
x = int(raw_input("Enter the fourth number: "))
mymax(x)

# Maximum between all inputs so far and max
x = int(raw_input("Enter the fifth number: "))
mymax(x)

# Print the maximum
print "The maximum number is", max
