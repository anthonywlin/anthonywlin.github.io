# sum0.py
x = raw_input("Enter the first number: ")
y = raw_input("Enter the second number: ")
z = raw_input("Enter the third number: ")

x = int(x) 
y = int(y)
x = x + y

print "The sum of the numbers is", x + int(z)
