# sum1.py
a = 0

x = raw_input("Enter the first number: ")
y = raw_input("Enter the second number: ")
z = raw_input("Enter the third number: ")

a = int(x) + int(y) + int(z)

print "The sum of the numbers is", a
