# sum2.py
# This program is supposed to do a sum

# Initialisation
sum = 0

# Inputting numbers from user and adding them to sum (after type conversion)
x = raw_input("Enter the first number: ")
sum += int(x)
x = raw_input("Enter the second number: ")
sum += int(x)
x = raw_input("Enter the third number: ")
sum += int(x)

# Outputting the sum
print "The sum of the numbers is", sum
