#error4.py
numEggs = 12
print 'I have ' + numEggs + ' eggs.'
