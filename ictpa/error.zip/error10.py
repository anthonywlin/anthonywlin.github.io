# error10.py
someVar = 42

def myFunction():
    print someVar 
    someVar = 100

myFunction()
