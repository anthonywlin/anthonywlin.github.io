# error9.py
# This is a Shape module

# Always put the import at the top
from swampy.TurtleWorld import *
import math

def polygon(t,n=7,len=70):
    """Drawing a polygon with n number of sides, each of length len. The turtle
    t starts drawing from a point and returns at that point when finished.
    """
    angle = 360.0/n
    for i in range(n):
        fd(t, len)
        lt(t,angle)

def circle(t,r):
    # Exercise: figure out the write docstring for circle
    circumference = 2 * math.pi * r
    n = int(circumference/3)+1
    len = circumference/n
    polygon(t,n,len)

# def square(turtle,length)
# Exercise: put your square function and write a docstring for it

# def rectangle(turtle,width,height)
# Exercise: put your rectangle function and write a docstring for it

world = TurtleWorld()
bob = Turtle()
bob.delay = 0.001
radius = 30
arc = 70
circle(bob,radius,arc)
wait_for_user()
