# error1.py
x = 7
if x == 7
    print x
