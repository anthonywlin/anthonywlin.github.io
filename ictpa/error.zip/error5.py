# error5.py
foobar = 'Al'
print 'My name is ' + fooba
