# error3.py
a = raw_input("Input a number: ")
x = raw_input("Input another number: ")
int(x)
int(a)
h = x // 24
s = x % 24
print h, s
a = a + s
print a
