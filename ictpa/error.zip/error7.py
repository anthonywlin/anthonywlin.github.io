#error7.py
str_time = raw_input("What time is it now?")
str_wait_time = raw_input("What is the number of nours to wait?")
time = int(str_time)
wai_time = int(str_wait_time)

time_when_alarm_go_off = time + wait_time
print time_when_alarm_go_off
