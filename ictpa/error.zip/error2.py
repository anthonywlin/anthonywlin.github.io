# error2.py
x = 3
if x = 7:
    print x
